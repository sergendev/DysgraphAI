/*:
 # DysgraphAI
 
 A playground using machine learning to detect dysgraphia in handwriting, with an interactive demo to help raise awareness about it.
 
 Please wait for a few seconds for the playground to start, and then, enjoy!
 
 ---
 
 ## What is Dysgraphia ? 🤔
 
 “Dysgraphia is a deficiency in the ability to write, primarily handwriting, but also coherence. Dysgraphia is a transcription disability, meaning that it is a writing disorder associated with impaired handwriting, orthographic coding, and finger sequencing (the movement of muscles required to write). It often overlaps with other learning disabilities such as speech impairment, attention deficit disorder, or developmental coordination disorder.”
 
  ☝️ From [Wikipedia](https://en.wikipedia.org/wiki/Dysgraphia)
 
 ---
 
 ## The Dataset ✍️
 
 The dataset for the machine learning model used in the playground was created originally, by digitally drawing about 50 samples of normal handwriting and handwriting with dysgraphia.
 
 ---
 
 ## Creating and Training The Model 👩‍🏫
 
 The model was created and trained using CreateML, using the interactive image classification tool; and the console output for further tuning.
 
 ---

 ## Credits and Thanks 🙏
 
 - [DSF](https://dsf.net.au/what-is-dysgraphia/) for the explanation of dysgraphia featured in the playground
 - [Sasmito Adibowo](https://github.com/adib) for his [blog post](https://cutecoder.org/programming/core-ml-swift-playgrounds/) on how to add `.mlmodel` files to Swift Playground
 
 ---
 
 ## Code Zone
 
 The later comments will get a little technical, explaining how each block of code works, step by step.
 Great care was taken to make the code modular and reusable, so you'll notice lots of functions instead of definitions.
 
 ---
*/
//: First, we import the libraries that we use in this page only (The playground has 4 more Swift files, and that's where CoreML is integrated)
import Foundation
import UIKit
import PlaygroundSupport
//: We define our main view (you may have noticed, with the WWDC19 signature blue) and set our live view to it
let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
containerView.backgroundColor = UIColor(displayP3Red: 0.0705, green: 0.0980, blue: 0.1764, alpha: 1)

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = containerView
//: We declare the animation modes so we can use them later on
enum animationMode {
    case animateIn
    case animateOut
}
//: This function here greatly simplifies making labels.
func makeLabel(label: UILabel, x: Int, y: Int, w: Int, h: Int, text: String, color: UIColor = UIColor.white, font: UIFont = UIFont.systemFont(ofSize: UIFont.systemFontSize), mainView: UIView = containerView) {
    
    label.lineBreakMode = .byWordWrapping
    label.numberOfLines = 12
    
    label.text = text
    label.frame = CGRect(x: x, y: y, width: w, height: h)
    label.adjustsFontSizeToFitWidth = true
    label.textColor = color
    label.font = font
    
    mainView.addSubview(label)
    
    label.sizeToFit()
}
//: These are the definitions for the content views that we later use in the playground.
var pageNumber = 1

let controller = ClassificationProvider()

// Page 1
let welcomeLabel = UILabel()
let titleLabel = UILabel()
let byLabel = UILabel()
let continueButton = UIButton()

// Page 2
let welcomeView = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
welcomeView.isUserInteractionEnabled = false

let welcomeTitleLabel = UILabel()
let welcomeInfoLabel = UILabel()

// Page 3
let infoView = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
infoView.isUserInteractionEnabled = false

let dysgraphiaTitleLabel = UILabel()
let dysgraphiaInfoLabel = UILabel()
let dysgraphiaImageView = UIImageView()

// Page 4
let aiInfoView = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
aiInfoView.isUserInteractionEnabled = false

let aiInfoTitleLabel = UILabel()
let aiInfoLabel = UILabel()

// Page 5
let aiView = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
aiView.isUserInteractionEnabled = true

let aiLabel = UILabel()
let aiInstructions = UILabel()
let aiPredictions = UILabel()
let predictButton = UIButton()
let clearButton = UIButton()
let drawingView = DysgraphiaView(frame: CGRect(x: 40, y: 90, width: 300, height: 275))

// Page 6
let thanksView = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
thanksView.isUserInteractionEnabled = false

let thanksTitle = UILabel()
let thanksMessageLabel = UILabel()

//: This function is probably the most important one: it makes the cool flying effect possible; it works by relating to the x and y values of the UI elements to the animation.
func animateSubviews(for view: UIView = containerView, mode: animationMode) {
    
    var animationCount = 0
    
    if mode == .animateIn {
        
        for subview in view.subviews {
            
            subview.center.x += view.bounds.width
            
            UIView.animate(withDuration: 1, delay: TimeInterval(0.4+(subview.center.y/500)), options: [.curveEaseOut, .preferredFramesPerSecond60],
                           animations: {
                            subview.center.x -= view.bounds.width
            },
                           completion: { (void) in
                            
                            animationCount += 1
                            
                            if pageNumber == 5 && animationCount == view.subviews.count {
                                // This is run after the last animation ends
                                aiView.addSubview(continueButton) }

            }
            )
        }
        
    } else {
        
        for subview in view.subviews {
            
            // This if statement is for preserving the 'Continue' button
            if subview.tag != 0xDABBAD00 {
                
                UIView.animate(withDuration: TimeInterval(0.8+(subview.center.y/10000)), delay: 0.3, options: [.curveEaseIn, .preferredFramesPerSecond60],
                               animations: {
                                subview.center.x -= view.bounds.width
                },
                               completion: { (void) in
                                
                                subview.removeFromSuperview()
                                
                                animationCount += 1
                                
                                if pageNumber == 7 && animationCount == view.subviews.count {
                                    // This is run after the last animation ends
                                    view.isHidden = true
                                    containerView.subviews.forEach { $0.removeFromSuperview() }
                                    view.isHidden = false
                                    pageNumber = 1
                                }
                    }
                )
            }
        }
    }
}

//: This function basically creates the content inside the playground, and then animates it using the above function.
func paginate() {
    switch pageNumber {
    case 1:
        makeLabel(label: welcomeLabel, x: 40, y: 30, w: 100, h: 30, text: "Welcome to", font: .systemFont(ofSize: 18))
        
        makeLabel(label: titleLabel, x: 40, y: 70, w: 600, h: 100, text: "DysgraphAI", font: .boldSystemFont(ofSize: 72))
        
        makeLabel(label: byLabel, x: 40, y: 180, w: 200, h: 30, text: "by Sergen Gönenç", font: .systemFont(ofSize: 18))
        
        continueButton.frame = CGRect(x: 450, y: 400, width: 140, height: 40)
        makeButton(button: continueButton, title: "Let's Start!", mainView: containerView)
        
        continueButton.tag = 0xDABBAD00
        
        animateSubviews(mode: .animateIn)
        break
    case 2:
        makeLabel(label: welcomeTitleLabel, x: 40, y: 20, w: 200, h: 40, text: "Welcome!", font: .boldSystemFont(ofSize: 32), mainView: welcomeView)
        
        welcomeInfoLabel.lineBreakMode = .byWordWrapping
        welcomeInfoLabel.numberOfLines = 12
        makeLabel(label: welcomeInfoLabel, x: 40, y: 80, w: 560, h: 400, text: "First of all, welcome to DysgraphAI! Today, we'll learn about what dysgraphia is, how it affects people, and then have a fun demo where you can check out an AI that tries to detect signs of dysgraphia, right in this playground!\n\nNow that you're probably curious about it, continue on to the next page to learn about it 🤓", font: .systemFont(ofSize: 24), mainView: welcomeView)
        welcomeInfoLabel.sizeToFit()
        containerView.addSubview(welcomeView)
        
        animateSubviews(for: welcomeView, mode: .animateIn)
        break
    case 3:
        labelize(titleLabel: dysgraphiaTitleLabel, titleText: "What is Dysgraphia?", descriptionLabel: dysgraphiaInfoLabel, descriptionText: "So what is this thing called dysgraphia, you may ask:\ndysgraphia is a learning disability that affects written expression. It can appear as difficulties with spelling, poor handwriting and trouble putting thoughts on paper. Some people may have poor handwriting, but dysgraphia is more serious; it is a neurological disorder that generally appears when children are first learning to write. To give you an idea, it usually looks like this:", mainView: infoView)
        
        dysgraphiaImageView.frame = CGRect(x: 40, y: 283, width: 265, height: 157)
        dysgraphiaImageView.image = UIImage(named: "dysgraphia.jpg")
        dysgraphiaImageView.layer.cornerRadius = 20
        dysgraphiaImageView.layer.masksToBounds = true
        infoView.addSubview(dysgraphiaImageView)
        
        containerView.addSubview(infoView)
        animateSubviews(for: infoView, mode: .animateIn)
        break
    case 4:
        labelize(titleLabel: aiInfoTitleLabel, titleText: "What is DysgraphAI?", descriptionLabel: aiInfoLabel, descriptionText: "Then what does this program do? It uses machine learning, created with the help of CreateML, to recognize signs of dysgraphia in handwriting ✍️\n\nMany people can confuse dysgraphia with just less-than-stellar handwriting; but machine learning, trained specifically to detect it, can immensely help us in this case.\n\nWhat's more, this learning disorder usually occurs along with other learning disabilities such as ADHD and dyslexia, so diagnosing dysgraphia can help diagnose these too!🔬", mainView: aiInfoView)
        containerView.addSubview(aiInfoView)
        animateSubviews(for: aiInfoView, mode: .animateIn)
        break
    case 5:
        predictButton.frame = CGRect(x: 220, y: 400, width: 100, height: 40)
        makeButton(button: predictButton, title: "Predict")
        clearButton.frame = CGRect(x: 60, y: 400, width: 100, height: 40)
        makeButton(button: clearButton, title: "Clear")
        
        makeLabel(label: aiLabel, x: 40, y: 20, w: 400, h: 40, text: "Let's try it, then!", font: .boldSystemFont(ofSize: 32), mainView: aiView)
        

        makeLabel(label: aiInstructions, x: 370, y: 90, w: 230, h: 500, text: "Write something short using your mouse/trackpad in the area and click 'Predict' to witness the magic ✨\n\nTip: Try writing normally at first, then try writing while shaking your hand, to see the machine learning in action 😉", font: .systemFont(ofSize: 16), mainView: aiView)

        makeLabel(label: aiPredictions, x: 370, y: 280, w: 300, h: 300, text: "Prediction:\nDysgraphia\n\n(Confidence: 100.0%)", font: .boldSystemFont(ofSize: 18), mainView: aiView)
        aiPredictions.isHidden = true
        
        drawingView.frame = CGRect(x: 40, y: 90, width: 300, height: 275)
        drawingView.mainImageView.image = UIImage.imageWithColor(tintColor: #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1))
        drawingView.layer.cornerRadius = 10.0
        drawingView.layer.masksToBounds = true

        aiView.addSubview(drawingView)
        
        containerView.addSubview(aiView)
        animateSubviews(for: aiView, mode: .animateIn)
        
        break
    case 6:
        labelize(titleLabel: thanksTitle, titleText: "That's about it!", descriptionLabel: thanksMessageLabel, descriptionText: "You've completed the playground 🎉! Now you're aware of this learning disability called dysgraphia, and have tried out a new way to diagnose it, with only a computer!\n\nThank you very much for tagging along in this journey, and hopefully, see you at WWDC19!", mainView: thanksView)
        
        continueButton.setTitle("Restart", for: .normal)
        continueButton.backgroundColor = #colorLiteral(red: 0.1411764771, green: 0.3960784376, blue: 0.5647059083, alpha: 1)
        
        containerView.addSubview(thanksView)
        animateSubviews(for: thanksView, mode: .animateIn)
        break
    default:
        break
    }
}
//: This code simplifies the process even more, since it allows us to create a whole page of the playground with just one line.
func labelize(titleLabel: UILabel, titleText: String, descriptionLabel: UILabel, descriptionText: String, mainView: UIView) {
    makeLabel(label: titleLabel, x: 40, y: 20, w: 400, h: 40, text: titleText, font: .boldSystemFont(ofSize: 32), mainView: mainView)
    
    descriptionLabel.lineBreakMode = .byWordWrapping
    descriptionLabel.numberOfLines = 12
    makeLabel(label: descriptionLabel, x: 40, y: 80, w: 560, h: 400, text: descriptionText, font: .systemFont(ofSize: 20), mainView: mainView)
    descriptionLabel.sizeToFit()
}

//: This code is responsible for creating the buttons you see inside the playground.

func makeButton(button: UIButton, title: String, mainView: UIView = aiView) {
    
    if title == "Let's Start!" {
        button.backgroundColor = #colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1)
    } else {
        button.backgroundColor = #colorLiteral(red: 0.1411764771, green: 0.3960784376, blue: 0.5647059083, alpha: 1)
    }
    
    button.layer.cornerRadius = 20
    button.titleLabel?.textColor = .white
    button.adjustsImageWhenHighlighted = true
    button.setTitle(title, for: .normal)
    mainView.addSubview(button)
}
//: This class defines the actions that happen when you press the buttons.
class Responder : NSObject {
    @objc func action() {
        
        switch pageNumber {
        case 1:
            animateSubviews(for: containerView, mode: .animateOut)
            break
        case 2:
            animateSubviews(for: welcomeView, mode: .animateOut)
            break
        case 3:
            animateSubviews(for: infoView, mode: .animateOut)
            break
        case 4:
            animateSubviews(for: aiInfoView, mode: .animateOut)
            break
        case 5:
            animateSubviews(for: aiView, mode: .animateOut)
            break
        case 6:
            animateSubviews(for: thanksView, mode: .animateOut)
            break
        default:
            break
        }
        
        pageNumber += 1
        
        animateButton(button: continueButton, duration: 0.5, endDuration: 0.3, endDelay: 1)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000), execute: {
            paginate()
            
        })
    }
    
    @objc func predict() {
        controller.updateClassifications(for: drawingView.mainImageView.image!)
        animateButton(button: predictButton, duration: 0.3, endDuration: 0.3, endDelay: 0.3)
    }
    
    @objc func clear() {
        
        drawingView.mainImageView.image = UIImage.imageWithColor(tintColor: #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1))
        animateButton(button: clearButton, duration: 0.1)
    }
}
//: This function makes the animations that happen when you press the buttons, and it is completely customizable.
func animateButton(button: UIButton, duration: TimeInterval, endDuration: TimeInterval = 0.1, endDelay: TimeInterval = 0.1) {
    UIView.animate(withDuration: duration, delay: 0.1, options: [.curveEaseIn, .preferredFramesPerSecond60],
                   animations: {
                    //continueButton.isEnabled = false
                    button.alpha = 0.3
                    
                    if button.title(for: .normal) == "Let's Start!" {
                        button.frame = CGRect(x: 470, y: 400, width: 120, height: 40)
                        button.setTitle("Continue", for: .normal)
                    }
                    
    },
                   completion: { (void) in
                    UIView.animate(withDuration: endDuration, delay: endDelay, animations: { button.alpha = 1
                        //continueButton.isEnabled = true
                    })
    }
    )
}
//: This code triggers when the predictions are done, and the code inside updates the playground with the results.
controller.predictionDoneClosure = {
    
    aiPredictions.isHidden = false
    
    var predictionsArray = controller.classificationLabel.components(separatedBy: " ")
    
    let prefixAttributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18)]
    let predictionAttributes = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 24)]
    let confidenceAttributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12)]
    
    if controller.classificationLabel == "Classifying..." {
        aiPredictions.text = "Predicting..."
    } else {
        
        let attributedString = NSMutableAttributedString(string: "Prediction:\n", attributes: prefixAttributes)
        attributedString.append(NSAttributedString(string: predictionsArray[1], attributes: predictionAttributes))
        attributedString.append(NSAttributedString(string: "\n\n(Confidence: \(predictionsArray[0])%)", attributes: confidenceAttributes))
        
        aiPredictions.attributedText = NSAttributedString(attributedString: attributedString)
    }
}
//: This creates and object of the class that we defined the button actions in,
let responder = Responder()
//: and then this code assigns the actions to the respective buttons.
continueButton.addTarget(responder, action: #selector(responder.action), for: .touchUpInside)

predictButton.addTarget(responder, action: #selector(responder.predict), for: .touchUpInside)

clearButton.addTarget(responder, action: #selector(responder.clear), for: .touchUpInside)
//: Finally, after all the setup is done, we call this function to show the content.
paginate()
//: Wow! If you are reading this, **thank you!** I am astonished by your patience. You now entirely know how this playground works, line by line.
//: ---
//: **Hope to see you at WWDC19!**
//: ---

//: Made with ❤️ by Sergen Gönenç, in ten days, and for only 399,99 lines (extras not included) :)
