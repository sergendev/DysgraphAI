import Foundation
import CoreML
import Vision
import UIKit

//: A slightly modified version of Apple's sample code for classifying images using Core ML and Vision

public class ClassificationProvider {
    
    public var predictionDoneClosure: (()->())?
    
    public var classificationLabel = "" {
        didSet {
            
            if oldValue != classificationLabel {
                predictionDoneClosure?()
            }
        }
    }
    
    public init() {
        
    }
    
    lazy var classificationRequest: VNCoreMLRequest = {
        do {
            let model = try VNCoreMLModel(for: DysgraphiaClassifier().model)
            
            let request = VNCoreMLRequest(model: model, completionHandler: { [weak self] request, error in
                self?.processClassifications(for: request, error: error)
            })
            request.imageCropAndScaleOption = .centerCrop
            return request
        } catch {
            fatalError("Failed to load Vision ML model: \(error)")
        }
    }()
    
    public func updateClassifications(for image: UIImage) {
        classificationLabel = "Classifying..."
        
        let orientation : CGImagePropertyOrientation = CGImagePropertyOrientation.up
        guard let ciImage = CIImage(image: image) else { fatalError("Unable to create \(CIImage.self) from \(image).") }
        
        DispatchQueue.global(qos: .userInitiated).async {
            let handler = VNImageRequestHandler(ciImage: ciImage, orientation: orientation)
            do {
                try handler.perform([self.classificationRequest])
            } catch {
                /*
                 This handler catches general image processing errors. The `classificationRequest`'s
                 completion handler `processClassifications(_:error:)` catches errors specific
                 to processing that request.
                 */
                print("Failed to perform classification.\n\(error.localizedDescription)")
            }
            
        }
    }
    
    //: Updates the classification string with the results
    func processClassifications(for request: VNRequest, error: Error?) {
        DispatchQueue.main.async {
            guard let results = request.results else {
                self.classificationLabel = "Unable to classify image.\n\(error!.localizedDescription)"
                return
            }
            // The `results` will always be `VNClassificationObservation`s, as specified by the Core ML model in this project.
            let classifications = results as! [VNClassificationObservation]
            
            if classifications.isEmpty {
                self.classificationLabel = "Nothing recognized."
            } else {
                // Display top classifications ranked by confidence in the UI.
                let topClassifications = classifications.prefix(2)
                let descriptions = topClassifications.map { classification in
                    // Formats the classification for display; e.g. "(0.37) cliff, drop, drop-off".
                    return String(format: "%.1f %@", classification.confidence*100, classification.identifier)
                }
                self.classificationLabel = descriptions.joined(separator: " ")
            }
        }
    }
}
